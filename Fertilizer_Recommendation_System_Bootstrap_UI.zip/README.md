
Bootstrap UI Fertilizer Recommendation System

Steps:
1. pip install -r requirements.txt
2. python model_train.py
3. python app.py
4. Open http://127.0.0.1:5000
