
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import pickle

df = pd.DataFrame({
    'N':[80,40,20,90],
    'P':[40,50,20,60],
    'K':[40,30,10,70],
    'ph':[6.5,7.0,5.5,6.8],
    'fertilizer':['Urea','DAP','Compost','NPK']
})

X = df[['N','P','K','ph']]
y = df['fertilizer']

model = RandomForestClassifier()
model.fit(X, y)

pickle.dump(model, open('model.pkl','wb'))
