
from flask import Flask, render_template, request
import pickle

app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = [
        int(request.form['N']),
        int(request.form['P']),
        int(request.form['K']),
        float(request.form['ph'])
    ]
    result = model.predict([data])[0]
    return render_template('result.html', fertilizer=result)

if __name__ == '__main__':
    app.run(debug=True)
